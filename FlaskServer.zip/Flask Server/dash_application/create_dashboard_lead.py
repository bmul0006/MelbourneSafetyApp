def create_dashboard_lead(flask_app):
        
    from dash import Dash, html, dcc, Input, Output, State
    import plotly.express as px
    import plotly.graph_objects as go
    import dash_bootstrap_components as dbc
    import pandas as pd
    import mysql.connector
    import sqlalchemy
    import textwrap

    # Connect to the database on the server

    mydb = mysql.connector.connect(
        host = "localhost",
        user = "<USER>",
        passwd = "<PASSWORD>",
        database = "<DATABASE>"
    )

    # Convert the sql query to a dataframe
    engine = sqlalchemy.create_engine('mysql+pymysql://group13:admin@<IP_ADDRESS>:<PORT>/<DATABASE>')
    query = '''select * from crime_stats2'''
    df = pd.read_sql_query(query, engine)

    # Clean string names
    df["Offence_Division"] = df["Offence_Division"].str.slice(start=2)
    df["Offence_Subdivision"] = df["Offence_Subdivision"].str.slice(start=4)
    df["Offence_Subgroup"] = df["Offence_Subgroup"].str.slice(start=4)

    def query_on_LGA(lga):
        # Select LGA
        # lga = "Stonnington"
        lga_data = df[df["Local_Government_Area"] == lga]

        # ADDED BY Osman - Start
        # Extract population for chosen LGA
        engine = sqlalchemy.create_engine('mysql+pymysql://group13:admin@<IP_ADDRESS>:<PORT>/<DATABASE>')
        query = '''SELECT Population_000s 
                FROM CrimeDimension 
                WHERE Local_Government_Area = "%s"''' % (lga)
        population = pd.read_sql_query(query, engine)
        population = str(population)[-3:]

        # extract safety for chosen LGA
        engine = sqlalchemy.create_engine('mysql+pymysql://group13:admin@<IP_ADDRESS>:<PORT>/<DATABASE>')
        query = '''SELECT Rating
                FROM lga_ratings 
                WHERE Local_Government_Area = "%s"''' % (lga)

        rating = pd.read_sql_query(query, engine)
        rating = str(rating)[-1:]

        if rating == "5":
            safety_desc = "Exceptionally safe"
        elif rating == "4":
            safety_desc = "Very safe"
        elif rating == "3":
            safety_desc = "Safe"
        elif rating == "2":
            safety_desc = "Passable"
        else:
            safety_desc = "Concerning"

        # ADDED BY Osman - End

        return (lga, lga_data, population, rating, safety_desc)

    def create_layout_charts(lga, lga_data):
        # Pre-processing for Donut Chart
        div_data = lga_data[lga_data["Year"] == 2021]
        div_data = div_data.drop(columns=["Row_no", "Offence_Rate_per_100000_population", "Year"])
        div_data = div_data.groupby(['Offence_Division']).sum().reset_index()

        # Pre-processing for Line Chart
        time_data = df.drop(columns=["Row_no", "Offence_Count"])
        time_data = time_data.groupby(['Local_Government_Area', 'Year']).sum().reset_index()

        
        meta = ["Proportion of Various Offences"]
        # Donut chart
        donut1 = go.Figure(data=[go.Pie(labels=div_data["Offence_Division"],
                                        values=div_data["Offence_Count"],
                                        hole=1,
                                        textfont={"size": 1},
                                        )])

        #donut1.update_layout(
            #title="Proportion of Various Offences in 2021", font={"size":10})

        donut2 = go.Figure(data=[go.Pie(labels=div_data["Offence_Division"],
                                        values=div_data["Offence_Count"],
                                        hole=0.001,
                                        showlegend=False
                                        )])
        # Line chart
        line = go.Figure()

        yes_data = time_data[time_data["Local_Government_Area"] == lga]
        no_data = time_data[time_data["Local_Government_Area"] != lga]
        other_lga = no_data["Local_Government_Area"].unique()

        # Adding each line for each LGA
        count = 0
        legend = True
        for l in other_lga:
            if count > 0:
                legend = False
            count = 1
            only_data = no_data[no_data["Local_Government_Area"] == l]
            line.add_trace(go.Scatter(x=only_data["Year"], y=only_data["Offence_Rate_per_100000_population"],
                                    mode='lines',
                                    line=dict(color='lightgrey'),
                                    legendgroup='group1',
                                    name="Other LGAs",
                                    showlegend=legend
                                    ))

        line.add_trace(go.Scatter(x=yes_data["Year"], y=yes_data["Offence_Rate_per_100000_population"],
                                mode='lines',
                                line=dict(color='red'),
                                legendgroup='group2',
                                name=lga
                                ))

        #line.update_layout(width=400, height=450)

        line.update_layout(legend=dict(
            yanchor="top",
            y=1.02,
            xanchor="right",
            x=1.01,
            font=dict(size=9)
        ))

        line.update_layout(xaxis_title="Year", yaxis_title="Offence Rate (per 100,000)",
                        title=lga + " vs. Other LGAs' Offence Counts", font={"size": 11, "family": "Arial Bold"})

        line.update_layout(width=400, height=450)

        return (donut1, donut2, line)

    


    def wrapping(string):
        split_text = textwrap.wrap(string, width=20)
        return '<br>'.join(split_text)

    def create_dash_application():
        dash_app = Dash(
            server=flask_app,
            url_base_pathname="/dash/",
            external_stylesheets=[dbc.themes.BOOTSTRAP],
            meta_tags=[{'name': 'viewport',
                        'content': 'width=device-width, initial-scale=1.15, maximum-scale=1.5, minimum-scale=0.5,'}]
            )
        
        # dash_app.config.suppress_callback_exceptions = True

        
        #find way to get lga from routes_pathname_prefix
        lga = "Melbourne"


        lga, lga_data, population, rating, safety_desc = query_on_LGA(lga)
        donut1, donut2, line = create_layout_charts(lga, lga_data)
            
        @dash_app.callback(
            Output(component_id='bar_graph', component_property='figure'),
            Input(component_id='dropdown', component_property='value'))
            
        def update_graph(choice):
            # Selecting offence sub-divisions for 2021
            subdiv_data = lga_data[lga_data['Offence_Division'] == choice]
            subdiv_data = subdiv_data[subdiv_data["Year"] == 2021]
            subdiv_data = subdiv_data.groupby(['Offence_Subdivision']).mean()
            subdiv_data = subdiv_data.drop(columns=["Row_no", "Offence_Count", "Year"]).reset_index()
            # Making the labels wrap to prevent long lines
            subdiv_data["Offence_Subdivision"] = subdiv_data["Offence_Subdivision"].apply(wrapping)

            subdiv_data = subdiv_data.sort_values(by = ['Offence_Rate_per_100000_population'], ascending = False).head(5)

            subdiv_data["Offence_Subdivision"] = subdiv_data["Offence_Subdivision"].str[:35]

            fig = px.bar(subdiv_data, y="Offence_Rate_per_100000_population", x="Offence_Subdivision", orientation='v',
                        labels={
                            "Offence_Subdivision": "Offence Types",
                            "Offence_Rate_per_100000_population": "Offence Count"})
            fig.update_layout(xaxis={'categoryorder': 'total descending'})
            fig.update_traces(textfont_size=6.5)
            fig.update_xaxes(tickangle=90)
            #fig.update_layout(title="Top Five Offences in 2021 by Crime Group", font={"size": 10})
            fig.update_layout(width=400, height=450)

            return fig
        # Dashboard Layout
        dash_app.layout = dbc.Container([
            dbc.Row([
                html.H1(lga),
                html.H4("Population: " + str(population) + "k"),
                html.Div("Safety rating: " + rating + "/5"),
                html.Div("Description: " + safety_desc)
            ]),

                html.Div([html.Div("blank", style={'color': 'white'}),
                html.Div("blank", style={'color': 'white'}),
                html.Div(" "),
                html.H6("Proportion of Various Offences", style={'textAlign': 'center', 'size': 10}),
                dcc.Graph(
                    id='donut_chart',
                    figure=donut2)
            ], className='justify-content-center'
            ),

            html.Div([
                dcc.Graph(
                    id='donut_chart2',
                    figure=donut1)
            ], className='justify-content-center'
            ),

            html.Div([
                    html.H6("Top Five Offences by Crime Groups", style={'textAlign': 'center', 'size': 10}),
                    html.Div("blank", style={'color': 'white'}),
                # Dropdown menu
                dcc.Dropdown(id='dropdown',
                            options=[
                                {'label': 'Crimes against the person', 'value': 'Crimes against the person'},
                                {'label': 'Property and deception offences', 'value': 'Property and deception offences'},
                                {'label': 'Drug offences', 'value': 'Drug offences'},
                                {'label': 'Public order and security offences', 'value': 'Public order and security offences'},
                                {'label': 'Other offences', 'value': 'Other offences'}
                            ],
                            value='Crimes against the person')
                #                      style={'width':'60%', 'margin':'auto'}
                #                     ),
                #         className='justify-content-center'
            ]),

            html.Div([
                dcc.Graph(
                    id='bar_graph',
                    figure={})
            ]),

            dbc.Row([
                dcc.Graph(
                    id='line_chart',
                    figure=line)
            ], className='justify-content-center')

        ])
        return dash_app
    return create_dash_application()
