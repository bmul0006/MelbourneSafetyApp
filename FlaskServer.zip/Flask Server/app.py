from flask import Flask, request, render_template, jsonify, make_response, redirect
import mysql.connector
import dash_application
import json


app = Flask(__name__) #references this file
dash_application.create_dashboard_lead(app)

mydb = mysql.connector.connect(
     host = "localhost",
     user = "<USER>",
     passwd = "<PASSWORD>",
     database = "<DATABASE>")

mycursor = mydb.cursor()


#ratings of LGA to be used in android app
@app.route('/lga_ratings')
def ratings():
    select_stmt = '''SELECT * FROM lga_ratings'''
    mycursor.execute(select_stmt)
    x = {"LGA":[]}
    for row in mycursor:
        lga = str(row)
        lga = lga.strip("()")
        lga_split = lga.split(',')
        lga_split[0] = lga_split[0].strip("'")
        lga_split[1] = int(lga_split[1])
        l = {"name": lga_split[0], "rating" : lga_split[1]}
        x["LGA"].append(l)

    return make_response(jsonify(x), 200)

#receives location information, updates DB and returns link to be sent to a trusted person
#format: <ip_address>/get_location?userID=<xxx>&lat=<xxx>&long=<xxx>
@app.route('/get_location')
def get_location():
    #receive location information
    userID = request.args.get('userID')
    lat = float(request.args.get('lat'))
    long = float(request.args.get('long'))
    #return str((lat,long))
    #update DB under user_location table
    insert_stmt = '''INSERT INTO user_location (userID, userLat, userLong) VALUES ('%s',%s, %s)
                     ON DUPLICATE KEY UPDATE userLat = %s, userLong = %s ''' % (userID, lat, long, lat, long)
    mycursor.execute(insert_stmt)
    mydb.commit()

    #return link to tracking page
    return "http://<IP_ADDRESS>/track?userID=" + userID

#<ip_address>/track?appID=<xxx>
@app.route('/track')
def track_link():
   #receive userID
   userID = request.args.get('userID')
   #receive lat long of userID
   select_lat_long = '''SELECT userLat, userLong from user_location WHERE userID = '%s';''' % (userID)
   mycursor.execute(select_lat_long)

   for lat_long in mycursor:
      currlat, currlong = lat_long[0], lat_long[1]
   #currlat = float(request.args.get('currlat'))
   #currlong = float(request.args.get('currlong'))
   return render_template("track.html", appID=userID, currlat=currlat, currlong=currlong)

#ratings
@app.route('/police_lat_long')
def police_lat_long():
   select_stmt = '''SELECT * FROM police_stations2'''
   mycursor.execute(select_stmt)
   x = {"police_stations":[]}
   for row in mycursor:
      police = str(row)
      police = police.strip("()")
      police_split = police.split(',')
      police_split[0] = police_split[0].strip("'")
      police_split[3] = float(police_split[3])
      police_split[4] = float(police_split[4])
      l = {"name":police_split[0], "lat":police_split[3], "long":police_split[4]}
      x["police_stations"].append(l)
   return make_response(jsonify(x), 200)
   return x

if __name__ == "__main__":
    app.run(debug=False)

